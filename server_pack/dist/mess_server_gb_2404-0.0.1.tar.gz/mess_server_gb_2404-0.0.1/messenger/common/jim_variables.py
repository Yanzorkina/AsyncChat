# JIM
ACTION: str = 'action'
TIME: str = 'time'
CHAT_USER: str = 'user'
ACCOUNT_NAME: str = 'account_name'
PASSWORD: str = 'password'
SENDER: str = 'from'
DESTINATION: str = 'to'

PRESENCE: str = 'presence'
RESPONSE: str = 'response'
ERROR: str = 'error'
MESSAGE: str = 'message'
MESSAGE_TEXT: str = 'mess_text'
EXIT: str = 'exit'

# contacts list
GET_CONTACTS: str = 'get_contacts'
ADD_CONTACT: str = 'add_contact'
DEL_CONTACT: str = 'del_contact'
ALERT: str = 'alert'
TARGET_USER: str = 'target_user'
LIST_INFO: str = 'list_info'
USERS_REQUEST: str = 'users_request'


